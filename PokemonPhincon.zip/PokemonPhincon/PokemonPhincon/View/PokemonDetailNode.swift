//
//  PokemonCellNode.swift
//  PokemonPhincon
//
//  Created by sia santos on 31/05/24.
//

import SwiftUI

struct PokemonDetailNode: View {
	var pokemonUrl: String = ""
	@State private var pokemonData = ""
	@State private var pokemonDetail = MainService().getDefaultPokemonData()
	@State private var tapCatchButton = false
	
	var body: some View {
		let pokemonData = self.pokemonDetail
		ZStack {
			VStack {
				HStack {
					PokemonImage(pokemonUrl: pokemonUrl, imageSize: 80)
					
					Spacer()
					
					VStack {
						Text("Name: \(pokemonData.name)")
						Text("Type: \(pokemonData.types[0].type.name)")
					}
					
					Spacer()
					
					Button(action: {
						withAnimation {
							tapCatchButton = true
						}
					}) {
						Text("Catch")
							.background(Color.blue)
							.foregroundColor(.white)
							.frame(width: 60, height: 50)
							.font(.system(size: 20, weight: .none, design: .default))
					}
				}
				.frame(minWidth: 100, maxWidth: .infinity, minHeight: 50)
				.padding(EdgeInsets(top: 0, leading: 32, bottom: 0, trailing: 32))
				
				MovesCellNode(pokemonDetail: pokemonData)
			}
			.edgesIgnoringSafeArea(.bottom)
			.onAppear {
				getPokemonData(url: pokemonUrl)
			}
			
			if tapCatchButton {
				CatchButton(tapCatchButton: $tapCatchButton, pokemonData: pokemonData)
			}
		}
	}
	
	func getPokemonData(url: String) {
		MainService().getPokemonData(pokemonUrl: url) { data in
			self.pokemonDetail = data
		}
	}
}

struct CatchButton: View {
	@Binding var tapCatchButton: Bool
	@State private var showFieldText: Bool = false
	var pokemonData: PokemonDetail
	
	var body: some View {
		if tapCatchButton {
			Color.black.opacity(0.4)
				.edgesIgnoringSafeArea(.all)
				.onTapGesture {
					withAnimation {
						tapCatchButton = false
					}
				}
			
			VStack {
				
				let isCatchPokemonSuccess = MainService().catchPokemon()
				
				Text(isCatchPokemonSuccess ? "SUCESS" : "FAILED")
					.font(.title)
					.padding()
				
				HStack {
					if isCatchPokemonSuccess {
						TextFieldRename(showTextField: $tapCatchButton, pokemonData: pokemonData)
					} else {
						
						Button(action: {
							withAnimation {
								tapCatchButton = false
							}
						}) {
							
							Text("Dismiss")
								.font(.title)
								.padding()
								.background(Color.red)
								.foregroundColor(.white)
								.cornerRadius(10)
						}
					}
				}
			}
			.frame(width: 300, height: 250)
			.background(Color.white)
			.cornerRadius(20)
			.shadow(radius: 20)
			.transition(.scale)
		}
	}
}

struct TextFieldRename: View {
	@Binding var showTextField: Bool
	var pokemonData: PokemonDetail

	@State private var textFields: String = ""
	@State private var textFieldsCount: Int = 0
	
	var body: some View {
		if showTextField {
			VStack {
				TextField("Enter Nickname", text: $textFields)
					.textFieldStyle(RoundedBorderTextFieldStyle())
					.disableAutocorrection(true)

				Button(action: {
					MainService().savePokemon(pokemonData: pokemonData, pokemonNickname: "\(textFields)")
					showTextField = false
				}) {
					Text("Save Nickname")
						.padding()
						.background(Color.green)
						.foregroundColor(.white)
						.cornerRadius(8)
				}
				.padding()
				Spacer()
			}
			.padding()
		}
	}
}

struct MovesCellNode: View {
	var pokemonDetail: PokemonDetail
	
	var body: some View {
		VStack {
			Text("Move List")
				.bold()
				.frame(maxWidth: .infinity, alignment: .leading)
				.padding(EdgeInsets(top: 28, leading: 32, bottom: 0, trailing: 0))
			List {
				ForEach(pokemonDetail.moves) { moves in
					VStack {
						Text("Move Name: \(moves.move.name)")
							.padding(10)
					}}}
		}
	}
}

#Preview {
	PokemonDetailNode()
}
