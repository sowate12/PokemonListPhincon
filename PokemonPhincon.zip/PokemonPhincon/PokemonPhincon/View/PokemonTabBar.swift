//
//  PokemonTabBar.swift
//  PokemonPhincon
//
//  Created by sia santos on 02/06/24.
//

import SwiftUI

enum TabBar: String, CaseIterable {
	case pokemonList
	case myPokemon
	
	var imageName: String {
		switch self {
		case .pokemonList:
			return "house"
		case .myPokemon:
			return "heart"
		}
	}
}

struct PokemonTabBar: View {
	@Binding var selectedTab: TabBar
	
	private var iconFillImage: String {
		selectedTab.imageName + ".fill"
	}
	
	private var tabColor: Color {
		switch selectedTab {
		case .pokemonList:
			return .blue
		case .myPokemon:
			return .red
		}
	}
	
	var body: some View {
		VStack {
			HStack {
				ForEach(TabBar.allCases, id: \.rawValue) { tab in
					Spacer()
					Image(systemName: selectedTab == tab ? iconFillImage : tab.imageName)
						.foregroundColor(selectedTab == tab ? tabColor : .gray)
						.font(.system(size: 22))
						.onTapGesture {
							withAnimation(.easeInOut(duration: 0.1)) {
								selectedTab = tab
							}
						}
					Spacer()
				}
			}
			.frame(width: nil, height: 60)
			.background(.thinMaterial)
			.cornerRadius(10)
			.padding()
		}
	}
}

#Preview {
	PokemonTabBar(selectedTab: .constant(.pokemonList))
}
