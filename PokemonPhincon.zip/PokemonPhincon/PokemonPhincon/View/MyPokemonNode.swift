//
//  MyPokemonNode.swift
//  PokemonPhincon
//
//  Created by sia santos on 02/06/24.
//

import SwiftUI
import ComposableArchitecture

struct MyPokemonNode: View {
	@Bindable var store: StoreOf<MyPokemonDatasFeature>
	
	var body: some View {
		ZStack {
			List {
				Text("My Pokemon List")
					.bold()
				ForEach(store.myPokemonDatas) { (myPokemon: MyPokemonData) in
					HStack {
						AsyncImage(url: URL(string: myPokemon.pokemonDetail.sprites.front_default))
							.frame(width: 60, height: 60)
							.foregroundColor(Color.gray.opacity(0.60))
						
						VStack {
							Text("Name: \(myPokemon.pokemonDetail.name)")
							Text("Nick: \(myPokemon.nickname)")
						}
						
						Spacer()
						
						Button(action: {
//							store.send(.renamePokemon)
						}) {
							Text("Rename")
						}
						
						Spacer()
						Button(action: {
							store.send(.releasePokemon(id: myPokemon.id))
						}) {
							Text("Release")
								.foregroundStyle(.red)
						}
					}
					.frame(width: 300, height: 80)
					.padding(EdgeInsets(top: 0, leading: 12, bottom: 0, trailing: 12))
				}
			}
		}
		.alert($store.scope(state: \.alert, action: \.alert))
		.frame(minWidth: 100, maxWidth: .infinity, minHeight: 50)
	}
}

#Preview {
	MyPokemonNode(
		store: Store(
			initialState: MyPokemonDatasFeature.State(
				myPokemonDatas: IdentifiedArray(uniqueElements: MainService().getPokemonDataCache())
			)
		){
			MyPokemonDatasFeature()
		}
	)
}
