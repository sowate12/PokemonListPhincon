//
//  PokemonImage.swift
//  PokemonPhincon
//
//  Created by sia santos on 01/06/24.
//

import SwiftUI

struct PokemonImage: View {
	var pokemonUrl: String
	var isImageRounded: Bool = true
	var imageSize: CGFloat = 75
	@State var imageUrl: String = ""
	
	var body: some View {
		AsyncImage(url: URL(string: imageUrl))
			.frame(width: imageSize, height: imageSize)
			.onAppear {
				// Cache Image
				getPokemonData(url: pokemonUrl)
				
			}.foregroundColor(Color.gray.opacity(0.60))
	}
	
	func getPokemonData(url: String) {
		MainService().getPokemonData(pokemonUrl: url) { data in
			imageUrl = data.sprites.front_default
		}
	}
}

#Preview {
	PokemonImage(pokemonUrl: "")
}
