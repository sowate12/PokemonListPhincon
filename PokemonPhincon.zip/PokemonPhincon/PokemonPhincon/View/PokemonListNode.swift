//
//  ContentView.swift
//  PokemonPhincon
//
//  Created by sia santos on 31/05/24.
//

import SwiftUI
import SwiftData
import ComposableArchitecture
struct PokemonListNode: View {
	@State private var selectedTab: TabBar = .pokemonList
	
	var body: some View {
		
		ZStack {
			TabView(selection: $selectedTab) {
				ForEach(TabBar.allCases, id:  \.rawValue) { tab in
					
					if tab.rawValue == "pokemonList" {
						PokemonListView().tag(tab)
					} else {
						let getPokemonCachedData = MainService().getPokemonDataCache()
						MyPokemonNode(
							store: Store(
								initialState: MyPokemonDatasFeature.State(
									myPokemonDatas: IdentifiedArray(uniqueElements: getPokemonCachedData)
									)
								){
									MyPokemonDatasFeature()
								}
							)
							.navigationTitle("My Pokemon List")
							.tag(tab)
					}
				}
			}
			
			VStack (spacing: -20) {
				Spacer()
				PokemonTabBar(selectedTab: $selectedTab)
			}
		}
	}
}

struct PokemonListView: View {
	@State var pokemon = [PokemonData]()
	@State var searchText = ""

	var body: some View {
		NavigationView {
			List {
				ForEach(searchText == "" ? pokemon : pokemon.filter( {
					$0.name.contains(searchText.lowercased())
				})) { entry in
					HStack {
						PokemonImage(pokemonUrl: entry.url)
							.padding(.vertical, 10)
						NavigationLink(
							"\(entry.name)".capitalized,
							destination: PokemonDetailNode(pokemonUrl: entry.url))
					}
				}
			}.onAppear {
				MainService().getPokemonList() { pokemon in
					self.pokemon = pokemon
				}
			}
			.searchable(text: $searchText)
			.navigationTitle("Pokemon List")
		}
	}
}

struct ContentView_Previews: PreviewProvider {
	static var previews: some View {
		PokemonListNode()
	}
}
