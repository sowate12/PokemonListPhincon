//
//  MainService.swift
//  PokemonPhincon
//
//  Created by sia santos on 31/05/24.
// https://pokeapi.co/api/v2/


import Foundation

/// Pokemon List
struct Pokemon: Codable {
	var results: [PokemonData]
}

struct PokemonData: Codable, Identifiable {
	let id = UUID()
	var name: String
	var url: String
}

/// Pokemon Moves
struct MoveDetail: Codable, Identifiable {
	let id = UUID()
	let move: PokemonData
	let versionGroupDetails: [VersionGroupDetail]
	
	enum CodingKeys: String, CodingKey {
		case move
		case versionGroupDetails = "version_group_details"
	}
}

struct VersionGroupDetail: Codable {
	let levelLearnedAt: Int
	let moveLearnMethod: PokemonData
	let versionGroup: PokemonData
	
	enum CodingKeys: String, CodingKey {
		case levelLearnedAt = "level_learned_at"
		case moveLearnMethod = "move_learn_method"
		case versionGroup = "version_group"
	}
}

/// PokemonTypes
struct TypeDetail: Codable {
	let slot: Int
	let type: PokemonData
	
	enum CodingKeys: String, CodingKey {
		case type = "type"
		case slot = "slot"
	}
}

/// Pokemon Image
struct PokemonSprites: Codable {
	let front_default: String
}

/// Pokemon Detail
struct PokemonDetail: Codable {
	let name: String
	let weight: Int
	let sprites: PokemonSprites
	let moves: [MoveDetail]
	let types: [TypeDetail]
}

class MainService {
	let mainDomain = "https://pokeapi.co/api/v2/"
	
	func getPokemonList(completion: @escaping ([PokemonData]) -> ()) {
		guard let url = URL(string: "\(mainDomain)pokemon?limit=100") else {
			return
		}
		
		URLSession.shared.dataTask(with: url) { (data, response, error) in
			guard let data = data else {
				return
			}
			
			do {
				let pokemonList = try JSONDecoder().decode(Pokemon.self, from: data)
				
				DispatchQueue.main.async {
					completion(pokemonList.results)
				}
				
			} catch {
				print(error.localizedDescription)
				
			}
		}.resume()
	}
	
	func getPokemonData(pokemonUrl: String, completion: @escaping (PokemonDetail) -> ()) {
		guard let url = URL(string: pokemonUrl) else {
			return
		}
		
		URLSession.shared.dataTask(with: url) { (data, response, error) in
			guard let data = data else {
				return
			}
			
			do {
				let decoder = JSONDecoder()
				let pokemonDetail = try decoder.decode(PokemonDetail.self, from: data)
				DispatchQueue.main.async {
					completion(pokemonDetail)
				}
				
			} catch {
				completion(self.getDefaultPokemonData())
				print("Error decoding JSON: \(error)")
			}
		}.resume()
	}
	
	func catchPokemon() -> Bool {
		return Bool.random()
	}
	
	private func isPrime(_ number: Int) -> Bool {
		if number <= 1 {
			return false
		}
		if number <= 3 {
			return true
		}
		var i = 2
		while i * i <= number {
			if number % i == 0 {
				return false
			}
			i += 1
		}
		return true
	}

	func releasePokemon() -> Bool {
		let randomNumber = Int.random(in: 1...100) //
		return isPrime(randomNumber) //
	}
	
	func getPokemonDataCache() -> [MyPokemonData] {
		if let savedData = UserDefaults.standard.data(forKey: "myPokemonData") {
			if let decodedObjects = try? JSONDecoder().decode([MyPokemonData].self, from: savedData) {
				return decodedObjects
			}
		}
		
		return []
	}
	
	func savePokemon(pokemonData: PokemonDetail, pokemonNickname: String) {
		var objects: [MyPokemonData] = []
		
		if let savedData = UserDefaults.standard.data(forKey: "myPokemonData") {
			if let decodedObjects = try? JSONDecoder().decode([MyPokemonData].self, from: savedData) {
				objects = decodedObjects
			}
		}
		
		var tempMyPokemonData: MyPokemonData = MyPokemonData(pokemonDetail: pokemonData, nickname: pokemonNickname, renamedCount: 0)
		objects.append(tempMyPokemonData)
		
		if let encoded = try? JSONEncoder().encode(objects) {
			UserDefaults.standard.set(encoded, forKey: "myPokemonData")
		}
	}
	
	func getDefaultPokemonData() -> PokemonDetail {
		return PokemonDetail(
			name: "Mock",
			weight: 1,
			sprites: PokemonSprites(front_default: "mock"),
			moves: [MoveDetail(
				move: PokemonData(name: "mock", url: "mock"),
				versionGroupDetails: [VersionGroupDetail(levelLearnedAt: 0, moveLearnMethod: PokemonData(name: "mock", url: "mock"),
														 versionGroup: PokemonData(name: "mock", url: "mock"))])],
			types: [TypeDetail(slot: 0, type: PokemonData(name: "mock", url: "mock"))]
		)
	}
}
