//
//  RenamePokemonFeature.swift
//  PokemonPhincon
//
//  Created by sia santos on 03/06/24.
//

import SwiftUI
import ComposableArchitecture

@Reducer
struct RenamePokemonFeature {
	@ObservableState
	struct State: Equatable {
		var myPokemonDatas: MyPokemonData

		static func == (lhs: RenamePokemonFeature.State, rhs: RenamePokemonFeature.State) -> Bool {
			return false
		}
		
	}
	
	enum Action {
		case cancelButtontapped
		case delegate(Delegate)
		case saveButtonTapped
		case setName(String)
		
		enum Delegate {
			case saveRename(MyPokemonData)
		}
	}
	
	@Dependency(\.dismiss) var dismiss
	
	var body: some ReducerOf<Self> {
		Reduce { state, action in
			switch action {
			case .cancelButtontapped:
				return .run{_ in await self._dismiss}
			case .saveButtonTapped:
				return .run { [pokemon = state.myPokemonDatas] send in
					await send(.delegate(.saveRename(pokemon)))
					await self.dismiss()
				}
			case let .setName(name):
				state.myPokemonDatas.nickname = name
				return .none
			case .delegate:
				return .none
			}
		}
	}
}

struct RenamePokemonView: View {
	@Bindable var store: StoreOf<RenamePokemonFeature>
	
	var body: some View {
		Form {
			TextField("Nickname", text: $store.myPokemonDatas.nickname.sending(\.setName))
			Button("Save") {
				store.send(.saveButtonTapped)
			}
		}
		.toolbar {
			ToolbarItem {
				Button("Cancel") {
					store.send(.cancelButtontapped)
				}
			}
		}
	}
}


#Preview {
	RenamePokemonView(
		store: Store(
			initialState: RenamePokemonFeature.State(
				myPokemonDatas: MyPokemonData(pokemonDetail: MainService().getDefaultPokemonData(), nickname: "", renamedCount: 0)
			)
		){
			RenamePokemonFeature()
		}
	)
}
