//
//  MyPokemonListData.swift
//  PokemonPhincon
//
//  Created by sia santos on 03/06/24.
//

import Foundation
import ComposableArchitecture
import SwiftUI

struct MyPokemonData: Codable, Identifiable {
	let id: UUID = UUID()
	let pokemonDetail: PokemonDetail
	var nickname: String = ""
	var renamedCount: Int = 0
}

@Reducer
struct MyPokemonDatasFeature {
	@ObservableState
	struct State: Equatable {
		@Presents var renamePokemon: RenamePokemonFeature.State?
		@Presents var alert: AlertState<Action.Alert>?
		
		static func == (lhs: MyPokemonDatasFeature.State, rhs: MyPokemonDatasFeature.State) -> Bool {
			return false
		}
		
		var myPokemonDatas: IdentifiedArrayOf<MyPokemonData> = IdentifiedArray(uniqueElements: MainService().getPokemonDataCache())
	}
	
	enum Action {
		case renamePokemon(PresentationAction<RenamePokemonFeature.Action>)
		case releasePokemon(id: MyPokemonData.ID)
		case alert(PresentationAction<Alert>)
		
		enum Alert: Equatable {
			case confirmDeletion(id: MyPokemonData.ID)
		}
	}
	
	var body: some ReducerOf<Self> {
		Reduce { state, action in
			switch action {
				
			case .renamePokemon(.presented(.delegate(.saveRename(_)))):
				
				guard let pokemon = state.renamePokemon?.myPokemonDatas else {
					return .none
				}
				
				state.myPokemonDatas.append(pokemon)
				return .none
				
			case let .alert(.presented(.confirmDeletion(id: id))):
				state.myPokemonDatas.remove(id: id)
				return .none
				
			case .alert:
				return .none
				
			case let .releasePokemon(id: id):
				
				let isReleaseSuccess = MainService().releasePokemon()
				
				state.alert = AlertState {
					TextState(isReleaseSuccess ? "Success" : "Failed")
					
				} actions: {
					if isReleaseSuccess {
						ButtonState(role: .destructive, action: .confirmDeletion(id: id)) {
							TextState("Delete")
						}
					}
				}
				return .none
				
	case .renamePokemon(.presented(.setName(_))):
		return .none
		
	case .renamePokemon(.presented(.delegate(_))):
		return .none
		
	case .renamePokemon(.presented(.cancelButtontapped)):
		return .none
		
	case .renamePokemon(.presented(.saveButtonTapped)):
		return .none
	case .renamePokemon(.dismiss):
		return .none
	}
}

	.ifLet(\.$renamePokemon, action: \.renamePokemon) {
		RenamePokemonFeature()
	}

	.ifLet(\.$alert, action: \.alert)
}
}

struct MyPokemonListView: View {
	let store: StoreOf<MyPokemonDatasFeature>
	let getPokemonCachedData = MainService().getPokemonDataCache()
	
	var body: some View {
		NavigationStack {
			List {
				ForEach(store.myPokemonDatas) { pokemonData in
					Text(pokemonData.nickname)
				}
			}
		}
		.navigationTitle("My Pokemons")
	}
}

#Preview {
	MyPokemonListView(
		store: Store(
			initialState: MyPokemonDatasFeature.State(
				myPokemonDatas: IdentifiedArray(uniqueElements: MainService().getPokemonDataCache())
			)
		){
			MyPokemonDatasFeature()
		}
	)
}
